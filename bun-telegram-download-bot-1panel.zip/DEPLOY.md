# Deploy in 1Panel

1. Upload and extract the ZIP into a directory on the 1Panel server.
2. Copy `.env.example` to `.env` in that directory. Set `BOT_TOKEN` and `OWNER_ID`.
3. In **Containers > Composes**, create a project using **Path Selection**.
   Select the extracted `docker-compose.yml` by its full server path.

1Panel builds the image from the files in the extracted directory. The bot
uses Telegram polling and needs no published ports or reverse proxy. SQLite
persists in the `bot-data` Docker volume for the Compose project. For an
existing installation, migrate its SQLite database before switching volumes.

Set `SHAREBOX_URL` in `.env` to share files that exceed Telegram's upload
limit through your FileCodeBox instance.

[1Panel Compose documentation](https://1panel.pro/docs/v2/user_manual/containers/composes/)
