import { z } from "zod";

/**
 * Zod schema for environment configuration.
 * Validated at startup — invalid config crashes with a clear message.
 */
export const envSchema = z.object({
  BOT_TOKEN: z.string().min(1, "BOT_TOKEN is required"),

  OWNER_ID: z.coerce.number().int().positive(),

  ALLOWED_USERS: z
    .string()
    .default("")
    .transform((s) =>
      s ? s.split(",").map((n) => n.trim()).filter(Boolean).map(Number).filter((n) => !isNaN(n)) : [],
    ),

  ALLOWED_GROUPS: z
    .string()
    .default("")
    .transform((s) =>
      s ? s.split(",").map((n) => n.trim()).filter(Boolean).map(Number).filter((n) => !isNaN(n)) : [],
    ),

  TEMP_DIR: z.string().default("/tmp/bun-video-bot"),
  // Total budget for one download; large files over slow proxies need more
  // than the old fixed 5 minutes.
  DOWNLOAD_TIMEOUT_SECONDS: z.coerce.number().int().positive().default(3600),
  LOG_LEVEL: z
    .enum(["fatal", "error", "warn", "info", "debug", "trace"])
    .default("info"),
  DATABASE_PATH: z.string().default("./data/bot.db"),

  NODE_ENV: z
    .enum(["development", "production", "test"])
    .default("development"),

  PROXY_URL: z.string().trim().optional(),

  PROXY_ENABLED: z
    .string()
    .default("true")
    .transform((v) => v === "true" || v === "1"),

  TOR_ENABLED: z
    .string()
    .default("true")
    .transform((v) => v === "true" || v === "1"),

  TOR_PROXY_URL: z.string().trim().url()
    .refine((value) => /^socks5h?:\/\//i.test(value), "Tor proxy must use socks5 or socks5h")
    .default("socks5h://127.0.0.1:9050"),

  // Use aria2c as yt-dlp's external downloader for faster, multi-connection
  // transfers. yt-dlp still handles extraction/format selection — aria2 only
  // does the byte transfer. Requires aria2c on PATH.
  ARIA2_ENABLED: z
    .string()
    .default("false")
    .transform((v) => v === "true" || v === "1"),

  // FileCodeBox file-sharing fallback for videos over Telegram's upload cap.
  SHAREBOX_URL: z
    .string()
    .optional()
    .transform((v) => v?.trim() || undefined),
  // Public base URL baked into the share link users open. Falls back to
  // SHAREBOX_URL when unset (e.g. same hostname is publicly reachable).
  SHAREBOX_PUBLIC_URL: z
    .string()
    .optional()
    .transform((v) => v?.trim() || undefined),
  // Files at or above this size go to the file box; smaller ones send inline.
  SHAREBOX_MIN_SIZE_MB: z.coerce.number().positive().default(49.99),
  SHAREBOX_TOKEN: z
    .string()
    .optional()
    .transform((v) => v?.trim() || undefined),
});

/** Parsed environment configuration — fails fast at startup if invalid */
export const env = envSchema.parse(process.env);

/** Type of the parsed environment */
export type Env = z.infer<typeof envSchema>;
